// IMPORTS
import express from 'express';
import bodyParser from 'body-parser';

const server = express();
const today = new Date();

const submission = [];

// PORT
const port = 3000;

// FORM DATA ENCODER
server.use(bodyParser.urlencoded(
    {
        extended : true
    }
))

server.use(express.static('public'));

// INITIALIZE
server.get( '/' ,(req, res) => {
    res.render('index.ejs', {
        submission: submission
    });
})

// TO VIEW AN ARTICLE USING /p/:id PARAMETER
server.get( '/p/:id' ,(req, res) => {
    res.render('index.ejs', {
        submission: submission,
        id : req.params.id
    });
})

// GO TO SUBMIT FORM PAGE
server.get( '/submit' ,(req, res) => {
    res.render('submitblog.ejs');
})

// SUBMIT THE FORM
server.post( '/submit' ,(req, res) => {
    const arrLength = submission.length;

    submission.push({
        id : arrLength,
        title : req.body.title,
        author : req.body.author,
        submitDate : `${String(today.getMonth() + 1).padStart(2, '0')}/${String(today.getDate()).padStart(2, '0')}/${today.getFullYear()}`,
        content : req.body.content,
    });

    console.log(submission);

    res.render('index.ejs', {
        submission: submission
    });
})


// TO DELETE an article
server.get('/d/:id', (req, res) => {

    submission.splice(req.params.id, 1);
    console.log(submission);

    res.render('index.ejs', {
        submission: submission,
    });
}) 


server.listen(port, () => {
    console.log(`Listening to port ${port}`);
});